import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../constants/constants.dart';
import '../../../state/application_state.dart';
import '../search_bloc.dart';
import '../search_entity/search_model.dart';
import '../search_entity/searchproduct.dart';
import '../search_event.dart';

class SearchMob extends StatefulWidget {
  const SearchMob({Key? key}) : super(key: key);

  @override
  _SearchMobState createState() => _SearchMobState();
}

class _SearchMobState extends State<SearchMob> {
  final TextEditingController _searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => SearchBloc(),
      child: BlocConsumer<SearchBloc, BaseState>(
        listener: (context, state) {
          if (state is ErrorState) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.errorMessage),
                backgroundColor: Colors.red,
              ),
            );
          }
        },
        builder: (context, state) {
          return Scaffold(
            body: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  TextField(
                    controller: _searchController,
                    onChanged: (query) {
                      if (query.isNotEmpty) {
                        context.read<SearchBloc>().add(SearchQueryEvent(query));
                      }
                    },
                    decoration: InputDecoration(
                      hintText: "Search the items...",
                      hintStyle: GoogleFonts.poppins(
                        fontSize: 10.0.sp,
                      ),
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.all(const Radius.circular(8.0).r),
                      ),
                    ),
                  ),
                  height(16.h),
                  Expanded(
                    child: _buildResults(state),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildResults(BaseState state) {
    if (state is LoadingState) {
      return const Center(child: CircularProgressIndicator());
    } else if (state is SuccessState) {
      final products = state.successResponse as List<Product>;
      return GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.7,
        ),
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          print('===================================================$products');
          return ProductCard(product: product);
        },
      );
    } else {
      return const Center(child: Text('No results found'));
    }
  }
}
