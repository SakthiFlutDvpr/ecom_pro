import 'package:dio/dio.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sel_org/ui_1/product_search/search_entity/search_model.dart';
import 'package:sel_org/ui_1/product_search/search_event.dart';

import '../../environments/api_environments.dart';
import '../../state/application_state.dart';

class SearchBloc extends Bloc<SearchEvent, BaseState> {
  static const String udf1 = 'M07';

  SearchBloc() : super(InitialState()) {
    on<SearchQueryEvent>(_searchQuery);
  }

  Future<void> _searchQuery(
      SearchQueryEvent event, Emitter<BaseState> emit) async {
    emit(LoadingState());
    try {
      final apiResponse = await fetchSearchData(event.query, udf1);
      if (apiResponse.status == 200) {
        emit(SuccessState(successResponse: apiResponse.data));
      } else {
        emit(ErrorState(errorMessage: 'Error: ${apiResponse.message}'));
      }
    } catch (e) {
      emit(ErrorState(errorMessage: 'Failed to load search data: $e'));
    }
  }

  Future<ApiResponse> fetchSearchData(String query, String udf1) async {
    final url = buildUrl(query, udf1);
    print('Fetching data from URL: $url');

    try {
      final response = await Dio().get(url);

      print('Response data: ${response.data}');

      if (response.statusCode == 200) {
        try {
          return ApiResponse.fromJson(response.data);
        } catch (e) {
          throw Exception('Failed to parse response: $e');
        }
      } else {
        throw Exception(
            'Failed to load data, status code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to fetch data: $e');
    }
  }
}
