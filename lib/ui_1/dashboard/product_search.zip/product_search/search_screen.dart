import 'package:flutter/material.dart';
import 'package:sel_org/ui_1/product_search/search_binding/search_small_screen.dart';
import 'package:sel_org/utils/responsive_widget/responsive_widget.dart';

class searchScreen extends StatefulWidget {
  const searchScreen({super.key});
  static const String routeName = "/search";
  @override
  State<searchScreen> createState() => _searchScreenState();
}

class _searchScreenState extends State<searchScreen> {
  @override
  Widget build(BuildContext context) {
    return const ResponsiveWidget(
        largeScreen: SearchMob(),
        mediumScreen: SearchMob(),
        smallScreen: SearchMob());
  }
}
